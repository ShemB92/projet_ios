//
//  ContentView.swift
//  PgeConnexion
//
//  Created by Shem Buitruille on 2024-02-19.
//
import SwiftUI

let lightGreyColor = Color (red:239.0/255.0,green:243.0/255.0, blue:244.0/255.0)
let storedUsername = "Shem"
let stroredPassword = "ABC"
struct ContentView: View {
    
   @State var username: String = ""
    @State var password: String = ""
    @State var authentificationDidFail: Bool = false
    @State var authentificationDidSucceed: Bool = true
    
    var body: some View {
        ZStack{
            
            VStack{
                Text("Hello, you!")
                .padding()
                .font(.largeTitle)
            
              
                
                UsernameTextField(username: $username)
                
                PasswordSecureField(password: $password)
                if authentificationDidFail {
                    Text("Information incorrecte. Reessayez")
                        .offset(y: -10)
                        .foregroundColor(.red)
                    
                    
                }
                
                Button(action: {if self.username == storedUsername && self.password == stroredPassword{
                    self.authentificationDidSucceed = true
                    self.authentificationDidFail = false
                     }
                    else {
                    self.authentificationDidFail = true
                    self.authentificationDidSucceed = false
                     }
                    
                } ) {
                    Text("CONNEXION")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 220, height: 60)
                        .background(Color.black)
                  
                        }
                
                
        }
            .padding()
            if authentificationDidSucceed{
                Text("Connexion reussi")
                    .font(.headline)
                    .frame(width:250, height:80)
                background(Color.yellow)
                    .cornerRadius(20.0)
                   
            }
        }
        
    
  }
}



struct UsernameTextField: View {
    @Binding var username: String
    var body: some View {
        TextField(("Pseudo"), text:$username)
            .padding()
            .background(lightGreyColor)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}

struct PasswordSecureField: View {
    @Binding var password: String
    var body: some View {
                SecureField("Mot De Passe", text: $password)
            .padding()
            .background(lightGreyColor)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}
