//
//  PgeConnexionApp.swift
//  PgeConnexion
//
//  Created by Shem Buitruille on 2024-02-19.
//

import SwiftUI

@main
struct PgeConnexionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
